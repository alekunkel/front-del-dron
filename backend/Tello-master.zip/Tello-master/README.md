# CODE4FUN_Tello
Tello library developed by CODE4FUN team

:construction: This library is still in construction and is subject to change! Use at your own risk! :construction:

## Installation

Download or clone this library and run

```
python3 setup.py install
```

## Example Usage

```python
from tello import *
start()
takeoff()
land()
```


